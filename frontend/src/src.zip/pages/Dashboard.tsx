import { useState } from "react";
import Home from "./dashboard/Home";
import MyGames from "./dashboard/MyGames";
import CreateGame from "./CreateGame";
import Folder from "./dashboard/Folder";
import Flashcard from "./dashboard/Flashcard";
import { Reviewer } from "./dashboard/Reviewer";
import Groups from "./dashboard/Groups";
import Settings from "./dashboard/Settings";
import Profile from "./dashboard/Profile";

type MenuKey =
  | "home"
  | "create"
  | "mygames"
  | "flashcard"
  | "folder"
  | "reviewer"
  | "groups"
  | "profile"
  | "settings"
  | "logout";

export default function Dashboard() {
  const [active, setActive] = useState<MenuKey>("home");

  function renderContent() {
    switch (active) {
      case "create":
        return <CreateGame onCreated={() => setActive("mygames")} />;
      case "mygames":
        return <MyGames />;
      case "folder":
        return <Folder />;
      case "flashcard":
        return <Flashcard />;
      case "reviewer":
        return <Reviewer />;
      case "groups":
        return <Groups />;
      case "settings":
        return <Settings />;
      case "profile":
        return <Profile />;
      case "logout":
        // simple placeholder logout
        return (
          <div className="p-6">
            <h2 className="text-2xl text-[#ff69b4]">
              Logged out (placeholder)
            </h2>
            <p className="text-gray-300">Close the page or login again.</p>
          </div>
        );
      default:
        return <Home />;
    }
  }

  return (
    <div className="min-h-screen bg-linear-to-b from-black to-gray-900 text-white">
      <div className="max-w-7xl mx-auto flex gap-6 p-6">
        <aside className="w-72 bg-gray-900/60 backdrop-blur-sm rounded-xl p-4 flex flex-col gap-4">
          <div className="text-center mb-4">
            <h3 className="text-xl font-bold text-[#00ffff]">TiniThink</h3>
            <div className="text-sm text-gray-400">Arcade Quizzes</div>
          </div>

          <nav className="flex flex-col gap-2">
            <button
              onClick={() => setActive("home")}
              className={`text-left px-3 py-2 rounded-md ${
                active === "home"
                  ? "bg-[#00ffff]/20 text-[#00ffff]"
                  : "hover:bg-white/5"
              }`}
            >
              Dashboard
            </button>

            <button
              onClick={() => setActive("create")}
              className={`text-left px-3 py-2 rounded-md ${
                active === "create"
                  ? "bg-[#00ffff]/20 text-[#00ffff]"
                  : "hover:bg-white/5"
              }`}
            >
              Create Game
            </button>

            <button
              onClick={() => setActive("mygames")}
              className={`text-left px-3 py-2 rounded-md ${
                active === "mygames"
                  ? "bg-[#00ffff]/20 text-[#00ffff]"
                  : "hover:bg-white/5"
              }`}
            >
              My Games
            </button>
            <button
              onClick={() => setActive("flashcard")}
              className={`text-left px-3 py-2 rounded-md ${
                active === "flashcard"
                  ? "bg-[#00ffff]/20 text-[#00ffff]"
                  : "hover:bg-white/5"
              }`}
            >
              Flashcard
            </button>
            <button
              onClick={() => setActive("folder")}
              className={`text-left px-3 py-2 rounded-md ${
                active === "folder"
                  ? "bg-[#00ffff]/20 text-[#00ffff]"
                  : "hover:bg-white/5"
              }`}
            >
              Folder
            </button>
            <button
              onClick={() => setActive("reviewer")}
              className={`text-left px-3 py-2 rounded-md ${
                active === "reviewer"
                  ? "bg-[#00ffff]/20 text-[#00ffff]"
                  : "hover:bg-white/5"
              }`}
            >
              Reviewer
            </button>
            <button
              onClick={() => setActive("groups")}
              className={`text-left px-3 py-2 rounded-md ${
                active === "groups"
                  ? "bg-[#00ffff]/20 text-[#00ffff]"
                  : "hover:bg-white/5"
              }`}
            >
              Groups
            </button>
            <button
              onClick={() => setActive("profile")}
              className={`text-left px-3 py-2 rounded-md ${
                active === "profile"
                  ? "bg-[#00ffff]/20 text-[#00ffff]"
                  : "hover:bg-white/5"
              }`}
            >
              Profile
            </button>
            <button
              onClick={() => setActive("settings")}
              className={`text-left px-3 py-2 rounded-md ${
                active === "settings"
                  ? "bg-[#00ffff]/20 text-[#00ffff]"
                  : "hover:bg-white/5"
              }`}
            >
              Settings
            </button>
            <button
              onClick={() => setActive("logout")}
              className="text-left px-3 py-2 rounded-md hover:bg-white/5"
            >
              Logout
            </button>
          </nav>

          <div className="mt-auto border-t border-white/5 pt-4">
            <div className="text-sm text-gray-400 mb-2">Account</div>
            <div className="text-sm text-white/80">You</div>
          </div>
        </aside>

        <main className="flex-1 bg-neutral-900/60 backdrop-blur-sm rounded-xl p-6">
          {renderContent()}
        </main>
      </div>
    </div>
  );
}
