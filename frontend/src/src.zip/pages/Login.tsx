import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import Modal from "../components/Modal";

export default function Login() {
  const [showModal, setShowModal] = useState(false);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);

    // TEMP: demo login - replace with backend call later
    // Example backend call (later):
    // const res = await fetch("http://localhost:8080/auth/login", { method: "POST", ... })
    // if success: store token and navigate

    setTimeout(() => {
      setLoading(false);
      // navigate to dashboard after (dummy) success
      navigate("/dashboard");
    }, 600);
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-linear-to-b from-black to-gray-900 p-6">
      <div className="flex w-full max-w-6xl bg-linear-to-tr from-gray-800/70 to-gray-900 rounded-xl shadow-2xl overflow-hidden">
        <div className="hidden md:flex md:w-1/2 p-12 items-center justify-center bg-linear-to-br from-[#020014] to-[#0a0210]">
          <div className="text-center">
            <h1 className="text-4xl font-extrabold mb-4">
              <span className="text-[#00ffff] animate-pulse">Welcome to</span>
              <br />
              <span className="text-[#ff69b4] animate-pulse">TiniThink</span>
            </h1>
            <p className="text-gray-300 mt-2 max-w-xs">
              Arcade-style quizzes — build and play door-based runs.
            </p>
          </div>
        </div>

        <div className="w-full md:w-1/2 p-8 bg-gray-900">
          <div className="max-w-md mx-auto">
            <h2 className="text-3xl font-bold text-white mb-6 text-center">
              Login
            </h2>

            <form className="space-y-4" onSubmit={handleSubmit}>
              <input
                type="text"
                placeholder="Username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                required
                className="w-full px-4 py-3 rounded-lg bg-gray-800 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-[#00ffff]"
              />
              <input
                type="password"
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                className="w-full px-4 py-3 rounded-lg bg-gray-800 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-[#00ffff]"
              />

              <button
                type="submit"
                disabled={loading}
                className="w-full py-3 rounded-lg bg-[#ff69b4] text-white font-semibold hover:bg-[#ff45a0] transform hover:scale-105 transition"
              >
                {loading ? "Signing in..." : "Login"}
              </button>
            </form>

            <div className="mt-6 flex items-center justify-between">
              <button
                onClick={() => setShowModal(true)}
                className="text-[#00ffff] hover:text-[#00cccc] text-sm"
              >
                Create account
              </button>

              <button
                onClick={() => alert("Forgot password (UI placeholder)")}
                className="text-sm text-gray-400 hover:text-white"
              >
                Forgot password?
              </button>
            </div>

            {showModal && <Modal onClose={() => setShowModal(false)} />}
          </div>
        </div>
      </div>
    </div>
  );
}
