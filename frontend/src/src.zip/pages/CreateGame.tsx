import { useState } from "react";

// Types
type ChoiceInput = { text: string; isCorrect: boolean };
type QuestionInput = { text: string; choices: ChoiceInput[] };

export default function CreateGame({ onCreated }: { onCreated?: () => void }) {
  const [title, setTitle] = useState("");
  const [questions, setQuestions] = useState<QuestionInput[]>([]);
  const [qText, setQText] = useState("");
  const [choiceInputs, setChoiceInputs] = useState<ChoiceInput[]>([
    { text: "", isCorrect: false },
    { text: "", isCorrect: false },
  ]);

  function updateChoiceInput(idx: number, v: string) {
    setChoiceInputs(
      choiceInputs.map((c, i) => (i === idx ? { ...c, text: v } : c))
    );
  }

  function markCorrect(idx: number) {
    setChoiceInputs(
      choiceInputs.map((c, i) => ({
        ...c,
        isCorrect: i === idx,
      }))
    );
  }

  function addQuestion() {
    if (!qText.trim()) return;
    if (!choiceInputs.some((c) => c.isCorrect)) {
      alert("Please select a correct answer.");
      return;
    }
    // Deep clone choices to avoid reference sharing bugs
    const clonedChoices = choiceInputs.map((c) => ({ ...c }));

    setQuestions((questions) => [
      ...questions,
      {
        text: qText.trim(),
        choices: clonedChoices,
      },
    ]);
    setQText("");
    setChoiceInputs([
      { text: "", isCorrect: false },
      { text: "", isCorrect: false },
    ]);
  }

  async function saveGame() {
    const payload = {
      title,
      creatorId: "user123",
      questions: questions.map((q) => ({
        text: q.text,
        timeLimit: 20,
        choices: q.choices.map((c) => ({
          text: c.text,
          correct: !!c.isCorrect,
        })),
      })),
    };

    try {
      const res = await fetch("http://localhost:8080/game/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      if (!res.ok) {
        const err = await res.text();
        alert("Failed to save game:\n" + err);
        return;
      }
      alert("Game saved successfully!");
      setTitle("");
      setQuestions([]);
      if (onCreated) onCreated();
    } catch (e: any) {
      alert("Error saving game:\n" + e.message);
    }
  }

  return (
    <div className="mb-8 p-4 bg-gray-900 rounded">
      <h2 className="text-2xl font-bold text-[#00ffff] mb-4">Create Game</h2>
      <input
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        placeholder="Game title"
        className="w-full px-3 py-2 rounded bg-gray-800 text-white mb-4"
      />
      <div>
        <label className="text-sm text-gray-300">Question</label>
        <textarea
          value={qText}
          onChange={(e) => setQText(e.target.value)}
          placeholder="Type your question"
          className="w-full px-3 py-2 rounded bg-gray-800 text-white mb-2"
        />
        <div className="mb-2">
          <div className="text-sm text-gray-300 mb-1">Choices</div>
          {choiceInputs.map((c, i) => (
            <div key={i} className="flex gap-2 mb-2 items-center">
              <input
                value={c.text}
                onChange={(e) => updateChoiceInput(i, e.target.value)}
                placeholder={`Choice ${i + 1}`}
                className="flex-1 px-3 py-2 rounded bg-gray-800 text-white"
              />
              <input
                type="radio"
                name="correct"
                checked={c.isCorrect}
                onChange={() => markCorrect(i)}
              />
              <span className="text-gray-300 text-xs">Correct</span>
            </div>
          ))}
          <button
            onClick={addQuestion}
            className="px-3 py-2 rounded bg-[#00ffff] text-black"
          >
            Add Question
          </button>
        </div>
      </div>
      <div className="mt-4">
        {questions.length > 0 && (
          <h3 className="font-bold text-gray-300 mb-2">Questions Added</h3>
        )}
        {questions.map((q, idx) => (
          <div key={idx} className="mb-2">
            <div className="text-white">{q.text}</div>
            <ul>
              {q.choices.map((c, i) => (
                <li key={i} className="text-gray-300">
                  {c.text}{" "}
                  {c.isCorrect && (
                    <span className="text-green-400 font-bold">(correct)</span>
                  )}
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
      <button
        onClick={saveGame}
        className="mt-4 px-4 py-2 bg-pink-600 text-white rounded font-bold"
      >
        Save Game
      </button>
    </div>
  );
}
