import React, { useState, useRef } from "react";

// Types
type FlashcardData = {
  id: string;
  question: string;
  answer: string;
  category: string;
};

const MOCK_FOLDER_FILES = [
  { id: "file1", name: "Biology_Lecture.pdf" },
  { id: "file2", name: "HistoryNotes.pdf" },
];

export default function Flashcard() {
  const [cards, setCards] = useState<FlashcardData[]>([]);
  const [question, setQuestion] = useState("");
  const [answer, setAnswer] = useState("");
  const [category, setCategory] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [loading, setLoading] = useState(false);
  const [showAIDialog, setShowAIDialog] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  function addCard() {
    if (!question.trim() || !answer.trim() || !category.trim()) {
      alert("Please fill out all fields and type a category.");
      return;
    }
    setCards([
      ...cards,
      {
        id: Date.now().toString(),
        question: question.trim(),
        answer: answer.trim(),
        category: category.trim(),
      },
    ]);
    setQuestion("");
    setAnswer("");
    setCategory("");
  }

  // Open AI generation dialog
  function openAIDialog() {
    setShowAIDialog(true);
  }

  // Handle file upload and AI flashcard generation
  async function handleFileUpload(e: React.ChangeEvent<HTMLInputElement>) {
    if (!e.target.files || e.target.files.length === 0) return;
    setLoading(true);
    setShowAIDialog(false);
    const formData = new FormData();
    formData.append("file", e.target.files[0]);
    const response = await fetch("/api/ai-flashcards-from-upload", {
      method: "POST",
      body: formData,
    });
    const data = await response.json();
    setCards((cards) => [
      ...cards,
      ...data.flashcards.map((fc: any, idx: number) => ({
        id: (Date.now() + idx).toString(),
        question: fc.question,
        answer: fc.answer,
        category: "AI Generated", // Default AI category
      })),
    ]);
    setLoading(false);
  }

  // AI from folder file
  async function generateFromFolderFile(fileId: string) {
    setLoading(true);
    setShowAIDialog(false);
    const response = await fetch("/api/generate-flashcards-from-file", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ fileId }),
    });
    const data = await response.json();
    setCards((cards) => [
      ...cards,
      ...data.flashcards.map((fc: any, idx: number) => ({
        id: (Date.now() + idx).toString(),
        question: fc.question,
        answer: fc.answer,
        category: "AI Generated", // Default AI category
      })),
    ]);
    setLoading(false);
  }

  // Dynamically generate unique categories from cards, plus "All" and AI
  const dynamicCategories = Array.from(
    new Set(["All", ...cards.map((c) => c.category), "AI Generated"])
  );

  // Filter cards based on selected category
  const visibleCards =
    selectedCategory === "All"
      ? cards
      : cards.filter((c) => c.category === selectedCategory);

  return (
    <div>
      <h2 className="text-xl font-bold mb-4">Flashcards</h2>
      {/* Controls row: Manual Add, AI, and Filter beside each other */}
      <div className="flex flex-wrap items-end gap-4 mb-8">
        <input
          value={question}
          onChange={(e) => setQuestion(e.target.value)}
          placeholder="Enter question"
          className="px-3 py-2 rounded bg-gray-800 text-white w-48"
        />
        <input
          value={answer}
          onChange={(e) => setAnswer(e.target.value)}
          placeholder="Enter answer"
          className="px-3 py-2 rounded bg-gray-800 text-white w-48"
        />
        <input
          value={category}
          onChange={(e) => setCategory(e.target.value)}
          placeholder="Type category"
          className="px-3 py-2 rounded bg-gray-800 text-white w-40"
        />
        <button
          onClick={addCard}
          className="px-4 py-2 bg-[#00ffff] text-black rounded font-bold"
        >
          Add Flashcard
        </button>
        <button
          onClick={openAIDialog}
          className="px-4 py-2 bg-[#ff69b4] text-white rounded font-bold"
          disabled={loading}
        >
          {loading ? "Processing..." : "Generate with AI"}
        </button>
        <select
          value={selectedCategory}
          onChange={(e) => setSelectedCategory(e.target.value)}
          className="px-3 py-2 rounded bg-gray-800 text-white w-36"
        >
          {dynamicCategories.map((c) => (
            <option key={c} value={c}>
              {c}
            </option>
          ))}
        </select>
      </div>
      {/* AI Dialog: Choose File Input or Folder */}
      {showAIDialog && (
        <div className="fixed z-50 left-0 top-0 w-full h-full bg-black/70 flex items-center justify-center">
          <div className="bg-white p-8 rounded-xl shadow max-w-md w-full relative">
            <h3 className="font-bold text-lg mb-4">
              Generate Flashcards with AI
            </h3>
            <p className="mb-2">Choose file source:</p>
            <div className="mb-4">
              <button
                onClick={() => fileInputRef.current?.click()}
                className="px-4 py-2 bg-blue-600 text-white rounded mr-4"
              >
                Input File from Device
              </button>
              <input
                type="file"
                style={{ display: "none" }}
                ref={fileInputRef}
                onChange={handleFileUpload}
                accept=".pdf,.doc,.docx,.txt"
              />
              <span className="text-gray-400 text-xs">
                (PDF, DOCX, TXT supported)
              </span>
            </div>
            <div>
              <p className="mb-1 font-semibold">
                Or use a file from your folder:
              </p>
              {MOCK_FOLDER_FILES.length === 0 && (
                <p className="text-gray-400">No files found in folder.</p>
              )}
              {MOCK_FOLDER_FILES.map((f) => (
                <div key={f.id} className="flex items-center gap-2 mb-2">
                  <span>{f.name}</span>
                  <button
                    className="px-2 py-1 bg-green-600 text-white rounded"
                    onClick={() => generateFromFolderFile(f.id)}
                  >
                    Use for Flashcards
                  </button>
                </div>
              ))}
            </div>
            <button
              className="absolute top-2 right-2 text-xl"
              onClick={() => setShowAIDialog(false)}
              title="Close"
            >
              ×
            </button>
          </div>
        </div>
      )}
      {/* Display cards */}
      <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-6">
        {visibleCards.length === 0 && (
          <div className="text-gray-400">
            No flashcards
            {selectedCategory !== "All" && ` in "${selectedCategory}"`} yet.
          </div>
        )}
        {visibleCards.map((card) => (
          <FlipCard
            key={card.id}
            question={card.question}
            answer={card.answer}
            category={card.category}
          />
        ))}
      </div>
    </div>
  );
}

// Flip-card component with click-to-flip
function FlipCard({
  question,
  answer,
  category,
}: {
  question: string;
  answer: string;
  category: string;
}) {
  const [flipped, setFlipped] = useState(false);

  return (
    <div
      className="group w-72 h-44 perspective cursor-pointer"
      onClick={() => setFlipped((f) => !f)}
      style={{ perspective: "1000px" }}
    >
      <div
        className={`relative w-full h-full transition-transform duration-500 ease-in-out ${
          flipped ? "transform rotate-y-180" : ""
        }`}
        style={{
          transformStyle: "preserve-3d",
        }}
      >
        {/* Front */}
        <div
          className="absolute w-full h-full bg-blue-600 text-white rounded-xl shadow-lg flex flex-col items-center justify-center text-center font-bold text-lg"
          style={{
            backfaceVisibility: "hidden",
            boxShadow: "0 4px 12px #0003",
          }}
        >
          {question}
          <div className="mt-2 text-xs font-normal text-gray-100">
            Category: {category}
          </div>
        </div>
        {/* Back */}
        <div
          className="absolute w-full h-full bg-green-600 text-white rounded-xl shadow-lg flex items-center justify-center text-center font-bold text-lg"
          style={{
            backfaceVisibility: "hidden",
            transform: "rotateY(180deg)",
            boxShadow: "0 4px 12px #0003",
          }}
        >
          {answer}
        </div>
      </div>
    </div>
  );
}
