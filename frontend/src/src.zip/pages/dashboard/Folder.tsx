import React, { useRef, useState } from "react";

// Utility: file extension to emoji
function FileIcon({ ext }: { ext: string }) {
  if (ext === "pdf") return <span className="mr-2 text-4xl">📄</span>;
  if (ext === "doc" || ext === "docx")
    return <span className="mr-2 text-4xl">📝</span>;
  return <span className="mr-2 text-4xl">📁</span>;
}

export default function Folder() {
  const [files, setFiles] = useState<File[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  function handleFilesSelected(e: React.ChangeEvent<HTMLInputElement>) {
    const filesArr = e.target.files ? Array.from(e.target.files) : [];
    setFiles((prev) => [...prev, ...filesArr]);
  }

  function openFileDialog() {
    fileInputRef.current?.click();
  }

  // DELETE: Remove file from array
  function handleDelete(idx: number) {
    setFiles((files) => files.filter((_, i) => i !== idx));
  }

  // OPEN: View file (PDF/doc/txt) in new tab using Blob URL
  function handleOpen(file: File) {
    const url = URL.createObjectURL(file);
    window.open(url, "_blank", "noopener,noreferrer");
    // Revoke URL after some time to avoid memory leaks (optional)
    setTimeout(() => URL.revokeObjectURL(url), 60000);
  }

  return (
    <div>
      {/* Header and Upload Button */}
      <div className="flex justify-between items-center mb-8">
        <h2 className="text-2xl font-bold text-gray-800">Folder</h2>
        <button
          onClick={openFileDialog}
          className="px-5 py-2 bg-blue-600 text-white rounded-full shadow hover:bg-blue-700 transition font-semibold"
        >
          Upload Files
        </button>
        <input
          type="file"
          ref={fileInputRef}
          hidden
          multiple
          accept=".pdf,.doc,.docx"
          onChange={handleFilesSelected}
        />
      </div>
      {/* Column/Grid view for files */}
      <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {files.length === 0 ? (
          <div className="text-gray-400 col-span-full mx-auto text-lg">
            No files uploaded yet.
          </div>
        ) : (
          files.map((file, idx) => (
            <div
              key={idx}
              className="bg-white/10 rounded-lg shadow group cursor-pointer p-6 flex flex-col items-center transition hover:shadow-xl hover:bg-white/20 relative"
              style={{ minHeight: 170 }}
            >
              <FileIcon ext={file.name.split(".").pop()?.toLowerCase() || ""} />
              <span
                className="font-semibold text-gray-900 text-center mt-2 w-full max-w-full wrap-break-word overflow-hidden"
                style={{
                  wordBreak: "break-word",
                  whiteSpace: "normal",
                  textOverflow: "ellipsis",
                }}
                title={file.name}
              >
                {file.name}
              </span>
              <span className="mt-1 text-xs text-gray-500">
                {(file.size / 1024).toFixed(1)} KB
              </span>
              <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition flex gap-2">
                <button
                  className="px-2 py-1 bg-gray-200 text-gray-800 rounded hover:bg-gray-300 text-xs"
                  onClick={() => handleOpen(file)}
                >
                  Open
                </button>
                <button
                  className="px-2 py-1 bg-red-100 text-red-600 rounded hover:bg-red-200 text-xs"
                  onClick={() => handleDelete(idx)}
                >
                  Delete
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
