import React, { useState } from "react";

export default function Settings() {
  // Example state for toggles/inputs (replace with your own logic as needed)
  const [username, setUsername] = useState("user123");
  const [email, setEmail] = useState("user@example.com");
  const [darkMode, setDarkMode] = useState(false);
  const [notifications, setNotifications] = useState(true);

  // Submit/save handler (implement according to your backend)
  function handleSave(e: React.FormEvent) {
    e.preventDefault();
    alert("Settings saved (not really, this is just a frontend demo)!");
    // Send updated settings to backend here
  }

  return (
    <div className="max-w-lg mx-auto p-4">
      <h2 className="text-2xl font-bold text-[#00ffff] mb-6">Settings</h2>
      <form onSubmit={handleSave} className="space-y-6">
        <div>
          <label className="font-semibold block mb-1">Username</label>
          <input
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            className="w-full px-3 py-2 rounded bg-gray-800 text-white"
            autoComplete="username"
          />
        </div>

        <div>
          <label className="font-semibold block mb-1">Email</label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full px-3 py-2 rounded bg-gray-800 text-white"
            autoComplete="email"
          />
        </div>

        <div className="flex items-center gap-3">
          <input
            type="checkbox"
            checked={darkMode}
            onChange={(e) => setDarkMode(e.target.checked)}
            id="darkMode"
          />
          <label htmlFor="darkMode" className="font-semibold">
            Dark Mode
          </label>
        </div>

        <div className="flex items-center gap-3">
          <input
            type="checkbox"
            checked={notifications}
            onChange={(e) => setNotifications(e.target.checked)}
            id="notifications"
          />
          <label htmlFor="notifications" className="font-semibold">
            Email Notifications
          </label>
        </div>

        {/* Add more settings here as needed */}

        <button
          type="submit"
          className="px-4 py-2 bg-[#00ffff] text-black rounded font-bold"
        >
          Save Settings
        </button>
      </form>
    </div>
  );
}
