import React, { useState } from "react";

export function Reviewer() {
  const [word, setWord] = useState("");
  const [reviewList, setReviewList] = useState<string[]>([]);

  function addWord() {
    if (!word.trim()) return;
    setReviewList((prev) => [...prev, word.trim()]);
    setWord("");
  }

  function removeWord(idx: number) {
    setReviewList((prev) => prev.filter((_, i) => i !== idx));
  }

  return (
    <div className="max-w-md mx-auto p-4">
      <h2 className="text-2xl font-bold text-[#00ffff] mb-4">Reviewer</h2>
      <div className="mb-4 flex gap-2">
        <input
          value={word}
          onChange={(e) => setWord(e.target.value)}
          placeholder="Add word or phrase to review"
          className="px-3 py-2 rounded bg-gray-800 text-white w-full"
        />
        <button
          onClick={addWord}
          className="px-4 py-2 bg-blue-600 text-white rounded font-bold"
        >
          Add
        </button>
      </div>
      <h3 className="font-semibold mb-2">Highlighted Words for Review</h3>
      <div className="space-y-2">
        {reviewList.length === 0 && (
          <div className="text-gray-400">No words highlighted yet.</div>
        )}
        {reviewList.map((w, idx) => (
          <div
            key={idx}
            className="flex justify-between items-center bg-white/5 rounded px-3 py-2"
          >
            <span className="font-bold text-[#00ffff]">{w}</span>
            <button
              className="text-red-400 px-2 py-1"
              onClick={() => removeWord(idx)}
              title="Remove"
            >
              ×
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
