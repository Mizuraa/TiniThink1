// Example mock data—replace these with real props or API data in your project!
const mockUser = {
  username: "user123",
  email: "user@example.com",
  avatar:
    "https://ui-avatars.com/api/?name=User+123&background=00ffff&color=fff",
  achievements: [
    { name: "Quiz Master", description: "Completed 50 quizzes", icon: "🏆" },
    { name: "Group Leader", description: "Created a group", icon: "👑" },
    {
      name: "Flashcard Pro",
      description: "Created 100 flashcards",
      icon: "💡",
    },
  ],
  groups: [
    { id: "g1", name: "Math Enthusiasts" },
    { id: "g2", name: "Biology Club" },
  ],
};

export default function Profile() {
  return (
    <div className="max-w-2xl mx-auto p-6">
      <h2 className="text-2xl font-bold text-[#00ffff] mb-6">Your Profile</h2>
      {/* Profile Info */}
      <div className="flex items-center gap-5 mb-8">
        <img
          src={mockUser.avatar}
          alt="User avatar"
          className="w-16 h-16 rounded-full border-2 border-[#00ffff] bg-white"
        />
        <div>
          <div className="font-bold text-lg">{mockUser.username}</div>
          <div className="text-gray-300">{mockUser.email}</div>
        </div>
      </div>
      {/* Achievements */}
      <div className="mb-8">
        <h3 className="font-semibold text-lg mb-3">Achievements</h3>
        <div className="flex gap-4 flex-wrap">
          {mockUser.achievements.length === 0 && (
            <div>No achievements yet.</div>
          )}
          {mockUser.achievements.map((a, idx) => (
            <div
              key={idx}
              className="bg-white/10 px-4 py-2 rounded flex items-center gap-2"
              title={a.description}
            >
              <span className="text-2xl">{a.icon}</span>
              <span className="font-bold">{a.name}</span>
            </div>
          ))}
        </div>
      </div>
      {/* Groups */}
      <div>
        <h3 className="font-semibold text-lg mb-3">Member of Groups</h3>
        <div className="flex gap-4 flex-wrap">
          {mockUser.groups.length === 0 && <div>No groups joined yet.</div>}
          {mockUser.groups.map((g) => (
            <div key={g.id} className="bg-white/10 px-4 py-2 rounded font-bold">
              {g.name}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
