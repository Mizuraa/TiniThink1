import { useRef, useState } from "react";
import type { MouseEvent } from "react";
import { IoCloseSharp } from "react-icons/io5";

type Props = {
  onClose: () => void;
};

export default function Modal({ onClose }: Props) {
  const modalRef = useRef<HTMLDivElement | null>(null);
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);

  const closeModal = (e: MouseEvent<HTMLDivElement>) => {
    if (modalRef.current === e.target) onClose();
  };

  async function handleCreate() {
    setMsg(null);
    setLoading(true);

    try {
      // placeholder: call backend signup when ready
      // const res = await fetch("http://localhost:8080/api/auth/signup", { method: "POST", headers: {...}, body: JSON.stringify({userName: username, email, password}) })
      // if (!res.ok) setMsg("error...")

      // For now simulate success:
      await new Promise((r) => setTimeout(r, 600));
      setLoading(false);
      setMsg("Account created — you can now login");
      setTimeout(onClose, 700);
    } catch (err: any) {
      setMsg(err?.message || "Network error");
      setLoading(false);
    }
  }

  return (
    <div
      ref={modalRef}
      onClick={closeModal}
      className="fixed inset-0 bg-black bg-opacity-60 backdrop-blur-sm flex items-center justify-center p-4 z-50"
    >
      <div className="bg-[#050014] border-2 border-[#00ffff] shadow-[0_0_25px_#00ffff] rounded-xl w-full max-w-md p-6 relative text-center font-mono">
        <button
          onClick={onClose}
          className="absolute right-3 top-3 text-[#ff69b4] hover:scale-110"
        >
          <IoCloseSharp size={24} />
        </button>

        <h2 className="text-3xl font-bold text-[#00ffff] mb-5 drop-shadow-[0_0_10px_#00ffff]">
          CREATE ACCOUNT
        </h2>

        <div className="space-y-3">
          <input
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            type="text"
            placeholder="Username"
            className="w-full px-4 py-3 bg-black text-[#00ffff] border border-[#00ffff] rounded-md focus:outline-none"
          />
          <input
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            type="email"
            placeholder="Email"
            className="w-full px-4 py-3 bg-black text-[#00ffff] border border-[#00ffff] rounded-md focus:outline-none"
          />
          <input
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            type="password"
            placeholder="Password"
            className="w-full px-4 py-3 bg-black text-[#00ffff] border border-[#00ffff] rounded-md focus:outline-none"
          />

          <button
            onClick={handleCreate}
            disabled={loading}
            className="w-full py-3 bg-[#ff69b4] rounded-md text-white font-bold tracking-widest hover:scale-105 transition shadow-[0_0_15px_#ff69b4]"
          >
            {loading ? "Creating..." : "CREATE ACCOUNT"}
          </button>

          {msg && <div className="text-sm mt-2 text-white/80">{msg}</div>}
        </div>
      </div>
    </div>
  );
}
